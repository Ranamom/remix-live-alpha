"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[540],{

/***/ 70540:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("# Files to exclude from Sindri circuit uploads (uses `.gitignore` syntax).\n/.deps/\n/scripts/\n/templates/\n");

/***/ })

}]);
//# sourceMappingURL=540.plugin-etherscan.1723117058823.js.map